package space.main.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import space.common.common.CommandMap;
import space.main.service.SpaceService;

@Controller
public class SpaceController {
	Logger log = Logger.getLogger(this.getClass());
	
	@Resource
	private SpaceService spaceService;
	
	@RequestMapping("/space/spaceList")
	private ModelAndView selectSpaceList(CommandMap map) {
		ModelAndView mav = new ModelAndView("index");
		
		map.put("ID", "admin");
		Map<String,Object> tempMap = spaceService.selectSpaceList(map.getMap());
		List<Map<String,Object>> list=(List<Map<String,Object>>)tempMap.get("SPACE_LIST");
		List<String> favList = (List<String>)tempMap.get("FAVORI_LIST");
		
		for(String str : favList) {
			log.debug("-------------------favList > " + str+"-------------------");
			
		}
		Iterator<Map<String,Object>> i = list.iterator();
		Map<String,Object> m = new HashMap<String,Object>();
		Set<String> key;
		String str="";
		while(i.hasNext()) {
			str="";
			m=i.next();
			key = m.keySet();
			for(String k : key) {
				str +=m.get(k)+",";
				
			}
			log.debug(key + " >>> "+str+"---------------------------------------");
		}
		
		return mav;
	}
	
	@RequestMapping("/space/SearchList")
	private ModelAndView selectSearchList(CommandMap map) {
		ModelAndView mav = new ModelAndView("admin/index");
		
		map.put("START_DATE", "2020-01-01");
		map.put("END_DATE", "2020-02-01");
		map.put("TYPE", "pri");
		map.put("USE", "");
		map.put("POS", "");
		map.put("SIZE", "");
		map.put("TITLE", "");
		List<Map<String,Object>> list = spaceService.selectSearchList(map.getMap());
		
		String str="";
		Set<String> key;
		for(Map<String,Object> m : list) {
			str="";
			key = m.keySet();
			for(String s : key) {
				str +=m.get(s)+",";
			}
			log.debug(key +" >>>" + str + "-----------------------------------------");
		}
		
		return mav;
	}
}
