package space.main.service;

import java.util.List;
import java.util.Map;

public interface SpaceService {
	Map<String,Object> selectSpaceList(Map<String,Object> map);
	List<Map<String,Object>> selectSearchList(Map<String,Object> map);
	Map<String,Object> selectDetailSpace(Map<String,Object> map);
	void favoriSpaceCheck(Map<String,Object> map);
}
