package space.main.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import space.main.dao.SpaceDao;

@Service("SpaceService")
public class SpaceServiceImpl implements SpaceService{
	Logger log = Logger.getLogger(this.getClass());
	@Resource
	private SpaceDao spaceDao;
	@Override
	public Map<String, Object> selectSpaceList(Map<String, Object> map) {
		Map<String,Object> tempMap = new HashMap<String, Object>();
		List<Map<String,Object>> list = spaceDao.selectSpaceList();
		List<String> favList = spaceDao.selectFavoriList(map);
		
		tempMap.put("SPACE_LIST", list);
		tempMap.put("FAVORI_LIST",favList);
		
		return tempMap;
	}
	@Override
	public List<Map<String,Object>> selectSearchList(Map<String, Object> map) {
		return spaceDao.selectSearchList(map);
	}
	@Override
	public Map<String, Object> selectDetailSpace(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void favoriSpaceCheck(Map<String, Object> map) {
		// TODO Auto-generated method stub
		
	}
	
	
}
