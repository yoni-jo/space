package space.main.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import space.common.dao.AbstractDAO;
@Repository
public class SpaceDao extends AbstractDAO{
	
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> selectSpaceList(){
		return (List<Map<String,Object>>)selectList("space.selectDefaultList");
	}
	
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> selectSearchList(Map<String,Object> map){
		return (List<Map<String,Object>>)selectList("space.selectSearchList",map);
	}
	
	@SuppressWarnings("unchecked")
	public List<String> selectFavoriList(Map<String,Object> map){
		return (List<String>)selectList("space.favoriList",map);
	}
	
}
