package space.main.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import space.main.dao.SpaceDao;

@Service("SpaceService")
public class SpaceServiceImpl implements SpaceService{
	Logger log = Logger.getLogger(this.getClass());
	@Resource
	private SpaceDao spaceDao;
	@Override
	public Map<String, Object> selectSpaceList(Map<String, Object> map) throws Exception{
		Map<String,Object> tempMap = new HashMap<String, Object>();
		List<Map<String,Object>> list = spaceDao.selectSpaceList();
		List<String> favList = spaceDao.selectFavoriList(map);
		
		tempMap.put("SPACE_LIST", list);
		tempMap.put("FAVORI_LIST",favList);
		
		return tempMap;
	}
	@Override
	public Map<String,Object> selectSearchList(Map<String, Object> map) throws Exception{
		Map<String,Object> tempMap = new HashMap<String, Object>();
		List<Map<String,Object>> list = spaceDao.selectSearchList(map);
		List<String> favList = spaceDao.selectFavoriList(map);
		
		tempMap.put("SPACE_LIST", list);
		tempMap.put("FAVORI_LIST",favList);
		
		return tempMap;
	}
	@Override
	public Map<String, Object> selectDetailSpace(Map<String, Object> map) throws Exception{
		Map<String,Object> tempMap = new HashMap<String, Object>();
		tempMap.put("DETAIL",spaceDao.selectDetailSpace(map));
		tempMap.put("QNA_LIST",spaceDao.selectSpaceQNA(map));
		tempMap.put("REPLY_LIST",spaceDao.selectSpaceReply(map));
		tempMap.put("RES_LIST", spaceDao.selectSpaceRes(map));
		
		return tempMap;
	}
	@Override
	public void updateFavoriSpace(Map<String, Object> map) throws Exception{
		spaceDao.updateFovoriSpace(map);
	}
	
	
}
