package space.main.service;

import java.util.List;
import java.util.Map;

public interface SpaceService {
	Map<String,Object> selectSpaceList(Map<String,Object> map) throws Exception;
	Map<String,Object> selectSearchList(Map<String,Object> map) throws Exception;
	Map<String,Object> selectDetailSpace(Map<String,Object> map) throws Exception;
	void updateFavoriSpace(Map<String,Object> map) throws Exception;
}
