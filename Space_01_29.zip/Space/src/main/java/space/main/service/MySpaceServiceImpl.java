package space.main.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service("MySpaceService")
public class MySpaceServiceImpl implements MySpaceService{

	@Override
	public List<Map<String, Object>> selectMySpaceList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteApplyBoard(Map<String, Object> map) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteSpaceBoard(Map<String, Object> map) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void holdSpaceBoard(Map<String, Object> map) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifySpaceBoard(Map<String, Object> map) {
		// TODO Auto-generated method stub
		
	}

}
