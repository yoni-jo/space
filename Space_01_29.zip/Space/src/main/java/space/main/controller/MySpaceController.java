package space.main.controller;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import space.common.common.CommandMap;
import space.main.service.SpaceService;

@Controller
public class MySpaceController {
Logger log = Logger.getLogger(this.getClass());
	
	@Resource
	private SpaceService spaceService;
	
	@RequestMapping("/mySpace/List")
	public ModelAndView test(CommandMap map) {
		ModelAndView mv = new ModelAndView();
			
		return mv;
	}
}
