package space.main.controller;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import space.common.common.CommandMap;
import space.main.service.SpaceService;

@Controller
public class ReserveController {
Logger log = Logger.getLogger(this.getClass());
	
	@Resource
	private SpaceService spaceService;
	
	@RequestMapping("/res/")
	private ModelAndView selectSpaceList(CommandMap map) throws Exception{
		ModelAndView mav = new ModelAndView("index");
		return mav;
	}
}
