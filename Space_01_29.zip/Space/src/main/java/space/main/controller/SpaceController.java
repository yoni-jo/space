package space.main.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import space.common.common.CommandMap;
import space.main.service.SpaceService;

@Controller
public class SpaceController {
	Logger log = Logger.getLogger(this.getClass());
	
	@Resource
	private SpaceService spaceService;
	
	@RequestMapping("/space/SpaceList")
	private ModelAndView selectSpaceList(CommandMap map) throws Exception{
		ModelAndView mav = new ModelAndView("main/main");
		
		map.put("USER_ID", "admin");
		Map<String,Object> tempMap = spaceService.selectSpaceList(map.getMap());
		List<Map<String,Object>> list=(List<Map<String,Object>>)tempMap.get("SPACE_LIST");
		List<String> favList = (List<String>)tempMap.get("FAVORI_LIST");
		
		for(String str : favList) {
			log.debug("-------------------favList > " + str+"-------------------");
			
		}
		Iterator<Map<String,Object>> i = list.iterator();
		Map<String,Object> m = new HashMap<String,Object>();
		Set<String> key;
		String str="";
		while(i.hasNext()) {
			str="";
			m=i.next();
			key = m.keySet();
			for(String k : key) {
				str +=m.get(k)+",";
				
			}
			log.debug(key + " >>> "+str+"---------------------------------------");
		}
		
		return mav;
	}
	
	@RequestMapping("/space/SearchList")
	private ModelAndView selectSearchList(CommandMap map) throws Exception{
		ModelAndView mav = new ModelAndView("main/spaceList");
		log.debug("START AND END DATE "+map.get("START_DATE") + "-" + map.get("END_DATE"));
		
		
		
		if (map.get("START_DATE") == null) {
			map.put("START_DATE", "2020-01-01");
			map.put("END_DATE", "2020-02-01");
		}
		String start = (String)map.get("START_DATE");
		String end =(String)map.get("END_DATE");
		List<String> dowList = toDAY_OF_WEEK(start,end);
		
		for(String s:dowList) {
			log.debug("-------------------dayOfweek > " +s+"-------------------");
		}
		
		map.put("SEARCH_TYPE", "pri");
		map.put("TITLE","1");
		map.put("POS", "����3��");
		map.put("USER_ID", "admin");
		
		Map<String,Object> tempMap = spaceService.selectSearchList(map.getMap());
		List<Map<String,Object>> list=(List<Map<String,Object>>)tempMap.get("SPACE_LIST");
		List<String> favList = (List<String>)tempMap.get("FAVORI_LIST");
		
		/*
		 * for(String str : favList) { log.debug("-------------------favList > " +
		 * str+"-------------------");
		 * 
		 * } Iterator<Map<String,Object>> i = list.iterator(); Map<String,Object> m =
		 * new HashMap<String,Object>(); Set<String> key; String str="";
		 * while(i.hasNext()) { str=""; m=i.next(); key = m.keySet(); for(String k :
		 * key) { str +=m.get(k)+",";
		 * 
		 * } log.debug(key + " >>> "+str+"---------------------------------------"); }
		 */
		
		mav.addObject("START_DATE", map.get("START_DATE"));
		mav.addObject("END_DATE", map.get("END_DATE"));
		
		return mav;
	}
	
	@RequestMapping("/space/detailSpace/{space_id}")
	private ModelAndView selectDetailSpace(CommandMap map,@PathVariable String space_id) throws Exception{
		ModelAndView mav = new ModelAndView("main/spaceDetail");
		map.put("SPACE_ID", space_id);
		Map<String,Object> spaceMap = spaceService.selectDetailSpace(map.getMap());
		
		if (spaceMap.get("DETAIL") != null) {
			Map<String, Object> temp = (Map<String, Object>) spaceMap.get("DETAIL");

			Set<String> sKey = temp.keySet();
			log.debug("==========================DETAIL LIST=====================================");
			for (String s : sKey) {
				log.debug(s + " >>> " + temp.get(s) + "---------------------------------------");
				if(s.equals("SPACE_TAG")) mav.addObject("TAG",divisionString("#",(String)temp.get(s)));
				else if(s.equals("SPACE_OPT")) mav.addObject("OPT",divisionString("/",(String)temp.get(s)));
				else if(s.equals("SPACE_USE")) mav.addObject("USE",divisionString("/",(String)temp.get(s)));
				else if(s.equals("SPACE_IMG")) mav.addObject("IMG",divisionString(",",(String)temp.get(s)));
			}
			log.debug("==========================DETAIL LIST END=====================================");
			mav.addObject("DETAIL",temp);
		}
		
		Set<String> set = spaceMap.keySet();
		List<Map<String, Object>> list;
		for (String name : set) {
			if (name.equals("DETAIL") || spaceMap.get(name) == null) continue;
			list = (List<Map<String, Object>>) spaceMap.get(name);
			
			if(name.equals("QNA_LIST")) mav.addObject("QNA_LIST",list);
			else if(name.equals("REPLY_LIST")) mav.addObject("REPLY_LIST",list);
			else if(name.equals("RES_LIST")) mav.addObject("RES_LIST",list);
				
			/*
			 * Iterator<Map<String, Object>> i = list.iterator(); Map<String, Object> m =
			 * new HashMap<String, Object>(); Set<String> key; String str = ""; while
			 * (i.hasNext()) { str = ""; m = i.next(); key = m.keySet(); for (String k :
			 * key) { str += m.get(k) + ",";
			 * 
			 * } log.debug(key + " >>> " + str + "---------------------------------------");
			 * }
			 */
		} 
		return mav;
	}
	
	@RequestMapping("/space/updateFavori")
	private ModelAndView updateFovoriSpace(CommandMap map) throws Exception{
		ModelAndView mav = new ModelAndView("admin/index");
		map.put("SPACE_ID", "20");
		map.put("USER_ID", "admin");
		spaceService.updateFavoriSpace(map.getMap());
		return mav;
	}
	
	@RequestMapping("/dd")
	public String test() {
		return "index";
	}
	
	
	private List<String> divisionString(String div,String str){
		String[] strArr = str.split(div);
		List<String> arrList = new ArrayList<String>();
		log.debug("[ ���ڿ� ]" +str+" [ ������ ] "+div);
		for(String s:strArr) {
			log.debug(">>>>>>>>>>>>>>>>  "+s);
			arrList.add(s);
		}
		return arrList;
		
	}
	
	private List<String> toDAY_OF_WEEK(String start,String end) throws Exception{
		List<String> list = new ArrayList<String>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd");
		Date startDate=dateFormat.parse(start);
		Date endDate=dateFormat.parse(end);
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(startDate);
		int sDayNum = cal.get(Calendar.DAY_OF_WEEK);
		cal.setTime(endDate);
		int eDayNum = cal.get(Calendar.DAY_OF_WEEK);
		
		while(true) {
			log.debug("sDayNum=================================="+sDayNum);
			if(sDayNum>Calendar.SATURDAY)  sDayNum = Calendar.SUNDAY;
			if(sDayNum == eDayNum) {
				list.add(insertDayOfWeek(sDayNum));
				break;
			}
			list.add(insertDayOfWeek(sDayNum));
			sDayNum++;
		}
		
		return list;
	}

	private String insertDayOfWeek(int num) {
		String day = null;
		switch (num) {
		case Calendar.SUNDAY:
			day = "SRES_SUN";
			break;
		case Calendar.MONDAY:
			day = "SRES_MON";
			break;
		case Calendar.TUESDAY:
			day = "SRES_TUE";
			break;
		case Calendar.WEDNESDAY:
			day = "SRES_WED";
			break;
		case Calendar.THURSDAY:
			day = "SRES_THU";
			break;
		case Calendar.FRIDAY:
			day = "SRES_FRI";
			break;
		case Calendar.SATURDAY:
			day = "SRES_SAT";
			break;

		}
		return day;
	}
}
