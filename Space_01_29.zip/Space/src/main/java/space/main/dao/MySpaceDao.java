package space.main.dao;

import org.springframework.stereotype.Repository;

import space.common.dao.AbstractDAO;
@Repository
public class MySpaceDao extends AbstractDAO{
	
}
